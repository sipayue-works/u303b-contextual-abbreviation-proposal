U+303B SUPPLEMENTARY MATERIALS
Prepared for an initial Unicode support/review inquiry
Date: 2026-09-05

Purpose
-------
This package supplements a proposal concerning the already encoded character
U+303B VERTICAL IDEOGRAPHIC ITERATION MARK (〻).

The package is intentionally modest. It is not a production-font submission
and does not request a new Unicode code point. It provides:
1. an SVG vector realization of the submitter's proposed glyph form;
2. the submitter-supplied raster reference image;
3. a concise glyph specification;
4. provenance, rights, and attribution notes;
5. submitter credentials and scope;
6. a font-status / technical-limitations note.

Important caveat
----------------
The submitter is not a font engineer or professional type designer. The SVG is
provided as technical/visual reference material. If Unicode reviewers later
require a standards-production font, the submitter intends to obtain technical
assistance and provide a properly licensed font at a later stage.

Formal submission process
-------------------------
This supplementary package does not replace the Unicode SEW Submission Form.
The email accompanying it should be treated as a support/routing inquiry and
request for guidance about the best handling of an existing-character glyph/use
proposal.

Primary character
-----------------
U+303B 〻 VERTICAL IDEOGRAPHIC ITERATION MARK

Requested conceptual review
----------------------------
- Whether the proposed hooked/calligraphic drawing can reasonably be treated as
  a glyphic variant of U+303B rather than a distinct encoded character.
- Whether U+303B can appropriately support an additional contextual
  abbreviation/omission use in Han-character text.
- What evidence, documentation, language-standardization support, or font
  material would be required if the proposal advances.

Files
-----
u303b_variant_glyph.svg
u303b_variant_reference.jpeg
GLYPH_SPECIFICATION_U303B.txt
PROVENANCE_RIGHTS_ATTRIBUTION.txt
SUBMITTER_CREDENTIALS_AND_SCOPE.txt
FONT_STATUS_AND_LIMITATIONS.txt

Official Unicode guidance consulted
-----------------------------------
https://sew.unicode.org/guidelines
https://www.unicode.org/policies/font_policy.html
https://www.unicode.org/faq/char_proposal.html
